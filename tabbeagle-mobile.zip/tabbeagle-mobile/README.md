# Tabbeagle — mobile (Expo / React Native)

Android-first client for the Tabbeagle backend (the `tabbeagle` Next.js
project — same Supabase project, same API). Login, dashboard with aging,
add invoice, send reminder, mark paid/promised/paused.

## Before running anything

This app talks to the **real backend**, so the backend must be deployed
first (see its own README): Supabase project created + migration run,
Vercel deploy live, Stripe + Resend keys configured.

## Setup

1. `cp .env.example .env.local` and fill in:
   - `EXPO_PUBLIC_SUPABASE_URL` / `EXPO_PUBLIC_SUPABASE_ANON_KEY` — same
     values as the backend's `.env.local`
   - `EXPO_PUBLIC_API_URL` — the backend's live Vercel URL (not
     localhost, unless testing on an emulator on the same machine)
2. In the Supabase dashboard, under Authentication > URL Configuration,
   add `tabbeagle://auth/callback` as a Redirect URL — without this, the
   magic-link email will not reopen the app.
3. `npm install`
4. `npm run android` (needs Android Studio + an emulator, or a device with
   USB debugging on) or `npm start` and scan the QR with Expo Go.

## Getting a real, installable APK (not just a dev build)

This sandbox has no internet access, so none of this has been run or
verified end to end — review it against Expo's current docs before
trusting it blindly:

1. `npm install -g eas-cli`
2. `eas login` (free Expo account)
3. `eas build:configure` — creates `eas.json`, links the project to your
   Expo account
4. `eas build --platform android --profile preview` — builds in Expo's
   cloud, no local Android SDK needed; returns a download link for a
   real `.apk` when it finishes (10–20 minutes)
5. Install that `.apk` directly on an Android phone, or upload it to the
   Play Console for internal testing

iOS later: same codebase, `eas build --platform ios` — needs an Apple
Developer account ($99/year) at that point, not before.

## What's here vs. what isn't

Built: login (magic link), dashboard (stats, aging buckets, invoice
list), reminder (3 tones, server generates a fresh Stripe link per
send), add invoice, mark paid/promised/paused.

Not here on purpose, matching the web app and the original product
brief: no CRM, no accounting, no WhatsApp yet, no offline mode, no push
notifications. Add those only once real users ask for them.

## Known gaps worth knowing about before a real pilot

- No pull-to-refresh error state beyond a basic alert — fine for a first
  pilot with a handful of users, worth hardening before a wider release.
- `getMyOrganizationId` assumes exactly one organization per owner,
  matching the backend's current v1 design. It will need to change the
  day Tabbeagle supports teams.
