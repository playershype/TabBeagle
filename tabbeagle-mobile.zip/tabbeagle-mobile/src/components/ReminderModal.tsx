import React, { useState } from 'react';
import { Modal, View, Text, Pressable, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import type { Invoice, Tone } from '../types';
import { fmtMoney } from '../lib/aging';
import { sendReminder } from '../lib/api';
import { colors } from '../theme';

const TONES: Tone[] = ['neutral', 'friendly', 'firm'];

// Preview text only, built locally — the real send always mints a fresh
// Stripe link server-side (see the backend's remind/route.ts), so this
// never shows a link that could go stale.
function preview(tone: Tone, clientName: string, amountCents: number, dueDate: string) {
  const amount = fmtMoney(amountCents);
  const bodies: Record<Tone, string> = {
    neutral: `Hi ${clientName},\n\nThis is a reminder that an invoice for ${amount} was due on ${dueDate}. Let me know if you have any questions.\n\n(a secure payment link will be included automatically)`,
    friendly: `Hey ${clientName}!\n\nJust a friendly nudge — the invoice for ${amount} was due on ${dueDate}. No worries if it slipped your mind.\n\n(a secure payment link will be included automatically)`,
    firm: `Hi ${clientName},\n\nThe invoice for ${amount}, due on ${dueDate}, remains unpaid. Please arrange payment as soon as possible.\n\n(a secure payment link will be included automatically)`,
  };
  return bodies[tone];
}

export default function ReminderModal({
  invoice,
  visible,
  onClose,
  onSent,
}: {
  invoice: Invoice | null;
  visible: boolean;
  onClose: () => void;
  onSent: (updated: Invoice) => void;
}) {
  const [tone, setTone] = useState<Tone>('neutral');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (!invoice) return null;

  const blocked = invoice.status === 'paused' || invoice.status === 'paid';

  async function handleSend() {
    setSending(true);
    setError(null);
    try {
      const updated = await sendReminder(invoice!.id, tone);
      onSent(updated);
    } catch (e: any) {
      setError(e.message || 'Could not send the reminder.');
    } finally {
      setSending(false);
    }
  }

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <Text style={styles.title}>{invoice.contact?.name}</Text>

          <View style={styles.tones}>
            {TONES.map((t) => (
              <Pressable
                key={t}
                onPress={() => setTone(t)}
                style={[styles.toneBtn, tone === t && styles.toneBtnActive]}
              >
                <Text style={[styles.toneText, tone === t && styles.toneTextActive]}>{t}</Text>
              </Pressable>
            ))}
          </View>

          <ScrollView style={styles.previewBox}>
            <Text style={styles.previewText}>
              {preview(tone, invoice.contact?.name || 'there', invoice.amount_cents, invoice.due_date)}
            </Text>
          </ScrollView>

          {blocked && (
            <Text style={styles.blockedText}>
              {invoice.status === 'paused'
                ? 'This invoice is paused — resume it before sending a reminder.'
                : 'This invoice is already paid.'}
            </Text>
          )}
          {error && <Text style={styles.blockedText}>{error}</Text>}

          <View style={styles.actions}>
            <Pressable style={styles.ghostBtn} onPress={onClose}>
              <Text style={styles.ghostBtnText}>Close</Text>
            </Pressable>
            <Pressable
              style={[styles.sendBtn, (blocked || sending || !invoice.contact?.email) && styles.disabled]}
              onPress={handleSend}
              disabled={blocked || sending || !invoice.contact?.email}
            >
              {sending ? <ActivityIndicator color="#fff" /> : <Text style={styles.sendBtnText}>Send email</Text>}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(15,30,54,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: colors.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '80%' },
  title: { fontSize: 18, fontWeight: '700', color: colors.ink, marginBottom: 10 },
  tones: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  toneBtn: { borderWidth: 1, borderColor: colors.line, borderRadius: 10, paddingVertical: 7, paddingHorizontal: 12 },
  toneBtnActive: { borderColor: colors.brass, backgroundColor: colors.brassBg },
  toneText: { fontSize: 13, color: colors.ink, textTransform: 'capitalize' },
  toneTextActive: { fontWeight: '600' },
  previewBox: { maxHeight: 140, borderWidth: 1, borderColor: colors.line, borderRadius: 10, padding: 10, marginBottom: 10 },
  previewText: { fontSize: 13, color: colors.ink, lineHeight: 19 },
  blockedText: { color: colors.rust, fontSize: 13, marginBottom: 8 },
  actions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8, marginTop: 4 },
  ghostBtn: { borderWidth: 1, borderColor: colors.line, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 16 },
  ghostBtnText: { color: colors.ink, fontSize: 14 },
  sendBtn: { backgroundColor: colors.ink, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 16 },
  sendBtnText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  disabled: { opacity: 0.5 },
});
