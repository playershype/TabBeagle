import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ActivityIndicator, Alert, ScrollView } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { createInvoice } from '../lib/api';
import { getMyOrganizationId } from '../lib/org';
import { colors } from '../theme';

type Props = NativeStackScreenProps<any>;

export default function AddInvoiceScreen({ navigation, route }: Props) {
  const [orgId, setOrgId] = useState<string | null>(null);
  const [client, setClient] = useState('');
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(''); // YYYY-MM-DD
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getMyOrganizationId().then(setOrgId).catch((e) => setError(e.message));
  }, []);

  async function handleSubmit() {
    if (!orgId) return;
    if (!client || !amount || !dueDate) {
      setError('Client, amount and due date are required.');
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      setError('Due date must be in YYYY-MM-DD format.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const invoice = await createInvoice({
        orgId,
        clientName: client,
        clientEmail: email || undefined,
        amount: Number(amount),
        dueDate,
      });
      route.params?.onCreated?.(invoice);
      navigation.goBack();
    } catch (e: any) {
      setError(e.message || 'Could not create the invoice.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScrollView style={styles.wrap} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.label}>Client name</Text>
      <TextInput style={styles.input} value={client} onChangeText={setClient} placeholder="Acme Studio" placeholderTextColor={colors.muted} />

      <Text style={styles.label}>Client email (for reminders)</Text>
      <TextInput
        style={styles.input} value={email} onChangeText={setEmail} placeholder="billing@acme.com"
        placeholderTextColor={colors.muted} autoCapitalize="none" keyboardType="email-address"
      />

      <Text style={styles.label}>Amount (USD)</Text>
      <TextInput
        style={styles.input} value={amount} onChangeText={setAmount} placeholder="1250.00"
        placeholderTextColor={colors.muted} keyboardType="decimal-pad"
      />

      <Text style={styles.label}>Due date</Text>
      <TextInput
        style={styles.input} value={dueDate} onChangeText={setDueDate} placeholder="2026-10-15"
        placeholderTextColor={colors.muted} keyboardType="numbers-and-punctuation"
      />

      {error && <Text style={styles.error}>{error}</Text>}

      <Pressable style={[styles.button, !orgId && styles.disabled]} onPress={handleSubmit} disabled={submitting || !orgId}>
        {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Add invoice</Text>}
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.paper },
  label: { fontSize: 13, fontWeight: '600', color: colors.ink, marginBottom: 6, marginTop: 14 },
  input: {
    borderWidth: 1, borderColor: colors.line, borderRadius: 10, padding: 13,
    fontSize: 15, backgroundColor: colors.card, color: colors.ink,
  },
  error: { color: colors.rust, fontSize: 13, marginTop: 14 },
  button: { backgroundColor: colors.ink, borderRadius: 10, padding: 15, alignItems: 'center', marginTop: 22 },
  disabled: { opacity: 0.5 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
