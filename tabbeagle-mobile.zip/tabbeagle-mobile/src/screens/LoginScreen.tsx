import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, ActivityIndicator } from 'react-native';
import * as Linking from 'expo-linking';
import { supabase } from '../lib/supabase';
import { colors } from '../theme';

// Matches the canonical web backend: magic link only, no passwords to
// manage for v1. Tapping the link in the email opens this app via the
// "tabbeagle://" scheme declared in app.json; App.tsx listens for that
// URL and exchanges it for a real session.
export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSend() {
    if (!email) {
      setError('Enter your email.');
      return;
    }
    setLoading(true);
    setError(null);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: Linking.createURL('auth/callback') },
    });
    setLoading(false);
    if (error) setError(error.message);
    else setSent(true);
  }

  return (
    <View style={styles.wrap}>
      <Text style={styles.brand}>Tabbeagle</Text>
      <Text style={styles.tagline}>Get paid without chasing customers.</Text>

      {sent ? (
        <Text style={styles.sentText}>
          Check your inbox for a magic link — tap it on this device and you're in.
        </Text>
      ) : (
        <>
          <TextInput
            style={styles.input}
            placeholder="you@business.com"
            placeholderTextColor={colors.muted}
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
          />
          <Pressable style={styles.button} onPress={handleSend} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Send magic link</Text>}
          </Pressable>
          {error && <Text style={styles.error}>{error}</Text>}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: colors.paper },
  brand: { fontSize: 30, fontWeight: '700', color: colors.ink, textAlign: 'center' },
  tagline: { fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 4, marginBottom: 32 },
  input: {
    borderWidth: 1, borderColor: colors.line, borderRadius: 10, padding: 14,
    fontSize: 16, marginBottom: 12, backgroundColor: colors.card, color: colors.ink,
  },
  button: { backgroundColor: colors.ink, borderRadius: 10, padding: 15, alignItems: 'center', marginTop: 8 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  sentText: { fontSize: 15, color: colors.ink, textAlign: 'center', lineHeight: 22 },
  error: { color: colors.rust, fontSize: 13, marginTop: 8, textAlign: 'center' },
});
