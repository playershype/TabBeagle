import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet, RefreshControl, ActivityIndicator, Alert, ScrollView, Modal, TextInput,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { Invoice, AgingBucket } from '../types';
import { bucketOf, daysOverdue, fmtMoney, outstandingTotal, recoveredThisMonth } from '../lib/aging';
import { fetchInvoices, updateInvoiceStatus } from '../lib/api';
import { supabase } from '../lib/supabase';
import { colors } from '../theme';
import ReminderModal from '../components/ReminderModal';

const BUCKETS: AgingBucket[] = ['current', '1-30', '31-60', '61-90', '90+'];
const LABELS: Record<AgingBucket, string> = {
  current: 'Current', '1-30': '1–30d', '31-60': '31–60d', '61-90': '61–90d', '90+': '90+d',
};
const BADGE_BG: Record<string, string> = {
  open: colors.rustBg, current: colors.sageBg, promised: colors.brassBg, paused: colors.line, paid: colors.sageBg,
};
const BADGE_FG: Record<string, string> = {
  open: colors.rust, current: colors.sage, promised: colors.brass, paused: colors.muted, paid: colors.sage,
};

type Props = NativeStackScreenProps<any>;

export default function DashboardScreen({ navigation }: Props) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<AgingBucket | 'all'>('all');
  const [reminderTarget, setReminderTarget] = useState<Invoice | null>(null);
  const [promiseTarget, setPromiseTarget] = useState<Invoice | null>(null);
  const [promiseDate, setPromiseDate] = useState('');

  const load = useCallback(async () => {
    try {
      const data = await fetchInvoices();
      setInvoices(data);
    } catch (e: any) {
      Alert.alert('Could not load invoices', e.message);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
  }, [load]);

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  function upsert(updated: Invoice) {
    setInvoices((prev) => {
      const exists = prev.some((i) => i.id === updated.id);
      return exists ? prev.map((i) => (i.id === updated.id ? updated : i)) : [updated, ...prev];
    });
  }

  async function markPaid(inv: Invoice) {
    try {
      upsert(await updateInvoiceStatus(inv.id, 'paid', { paid_date: new Date().toISOString().slice(0, 10) }));
    } catch (e: any) {
      Alert.alert('Could not update', e.message);
    }
  }
  function markPromised(inv: Invoice) {
    // Alert.prompt is iOS-only — it's silently absent on Android, which
    // is this app's primary platform, so a plain text modal is used for
    // both instead of a platform-specific dialog.
    setPromiseDate('');
    setPromiseTarget(inv);
  }

  async function confirmPromise() {
    if (!promiseTarget) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(promiseDate)) {
      Alert.alert('Invalid date', 'Use the YYYY-MM-DD format.');
      return;
    }
    try {
      upsert(await updateInvoiceStatus(promiseTarget.id, 'promised', { promised_date: promiseDate }));
      setPromiseTarget(null);
    } catch (e: any) {
      Alert.alert('Could not update', e.message);
    }
  }
  async function togglePause(inv: Invoice) {
    try {
      upsert(await updateInvoiceStatus(inv.id, inv.status === 'paused' ? 'open' : 'paused'));
    } catch (e: any) {
      Alert.alert('Could not update', e.message);
    }
  }

  const open = invoices.filter((i) => i.status !== 'paid');
  const needsAttention = open.filter((i) => i.status === 'open' && daysOverdue(i.due_date) > 0).length;
  const shown = invoices
    .filter((i) => (filter === 'all' ? i.status !== 'paid' : bucketOf(i) === filter))
    .sort((a, b) => a.due_date.localeCompare(b.due_date));

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={colors.ink} />
      </View>
    );
  }

  return (
    <View style={styles.wrap}>
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>Tabbeagle</Text>
          <Text style={styles.tagline}>Get paid without chasing customers.</Text>
        </View>
        <Pressable onPress={() => supabase.auth.signOut()}>
          <Text style={styles.signOut}>Sign out</Text>
        </Pressable>
      </View>

      <View style={styles.stats}>
        <Stat label="Outstanding" value={fmtMoney(outstandingTotal(invoices))} />
        <Stat label="Recovered this mo." value={fmtMoney(recoveredThisMonth(invoices))} />
        <Stat label="Need attention" value={String(needsAttention)} />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.ledger}>
        {BUCKETS.map((b) => {
          const items = open.filter((i) => bucketOf(i) === b);
          const sum = items.reduce((s, i) => s + i.amount_cents, 0);
          return (
            <Pressable key={b} onPress={() => setFilter(b)} style={[styles.ledgerChip, filter === b && styles.ledgerChipActive]}>
              <Text style={styles.ledgerAmt}>{fmtMoney(sum)}</Text>
              <Text style={styles.ledgerLbl}>{LABELS[b]} · {items.length}</Text>
            </Pressable>
          );
        })}
        <Pressable onPress={() => setFilter('all')} style={[styles.ledgerChip, filter === 'all' && styles.ledgerChipActive]}>
          <Text style={styles.ledgerAmt}>{open.length}</Text>
          <Text style={styles.ledgerLbl}>All open</Text>
        </Pressable>
      </ScrollView>

      <FlatList
        data={shown}
        keyExtractor={(i) => i.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={<Text style={styles.empty}>No invoices here. Add one below, or pick a different bucket.</Text>}
        renderItem={({ item: inv }) => {
          const days = daysOverdue(inv.due_date);
          let badge = 'open', label = `${days}d overdue`;
          if (inv.status === 'paid') { badge = 'paid'; label = 'Paid'; }
          else if (inv.status === 'paused') { badge = 'paused'; label = 'Paused'; }
          else if (inv.status === 'promised') { badge = 'promised'; label = `Promised ${inv.promised_date}`; }
          else if (days <= 0) { badge = 'current'; label = 'Current'; }
          return (
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.client}>{inv.contact?.name || 'Unknown client'}</Text>
                <Text style={styles.due}>{inv.due_date}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', marginRight: 10 }}>
                <Text style={styles.amount}>{fmtMoney(inv.amount_cents, inv.currency)}</Text>
                <View style={[styles.badge, { backgroundColor: BADGE_BG[badge] }]}>
                  <Text style={[styles.badgeText, { color: BADGE_FG[badge] }]}>{label}</Text>
                </View>
              </View>
              <View style={styles.actions}>
                <Pressable onPress={() => setReminderTarget(inv)}><Text style={styles.action}>Remind</Text></Pressable>
                <Pressable onPress={() => markPaid(inv)}><Text style={styles.action}>Paid</Text></Pressable>
                <Pressable onPress={() => markPromised(inv)}><Text style={styles.action}>Promise</Text></Pressable>
                <Pressable onPress={() => togglePause(inv)}>
                  <Text style={styles.action}>{inv.status === 'paused' ? 'Resume' : 'Pause'}</Text>
                </Pressable>
              </View>
            </View>
          );
        }}
      />

      <Pressable style={styles.fab} onPress={() => navigation.navigate('AddInvoice', { onCreated: upsert })}>
        <Text style={styles.fabText}>+ Add invoice</Text>
      </Pressable>

      <ReminderModal
        invoice={reminderTarget}
        visible={!!reminderTarget}
        onClose={() => setReminderTarget(null)}
        onSent={(updated) => { upsert(updated); setReminderTarget(null); }}
      />

      <Modal visible={!!promiseTarget} transparent animationType="fade" onRequestClose={() => setPromiseTarget(null)}>
        <View style={styles.promiseBackdrop}>
          <View style={styles.promiseSheet}>
            <Text style={styles.client}>Promised to pay on</Text>
            <TextInput
              style={styles.input}
              value={promiseDate}
              onChangeText={setPromiseDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={colors.muted}
              keyboardType="numbers-and-punctuation"
              autoFocus
            />
            <View style={styles.promiseActions}>
              <Pressable onPress={() => setPromiseTarget(null)}><Text style={styles.action}>Cancel</Text></Pressable>
              <Pressable onPress={confirmPromise}><Text style={[styles.action, { fontWeight: '700' }]}>Confirm</Text></Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.paper, paddingTop: 54 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.paper },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 16, marginBottom: 14 },
  brand: { fontSize: 22, fontWeight: '800', color: colors.ink },
  tagline: { fontSize: 12, color: colors.muted, marginTop: 2 },
  signOut: { fontSize: 13, color: colors.muted },
  stats: { flexDirection: 'row', paddingHorizontal: 16, marginBottom: 14, gap: 12 },
  statValue: { fontSize: 20, fontWeight: '800', color: colors.ink },
  statLabel: { fontSize: 11, color: colors.muted, marginTop: 2 },
  ledger: { paddingHorizontal: 16, marginBottom: 10, flexGrow: 0 },
  ledgerChip: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: 10, padding: 10, marginRight: 8, minWidth: 92 },
  ledgerChipActive: { borderColor: colors.brass, backgroundColor: colors.brassBg },
  ledgerAmt: { fontSize: 14, fontWeight: '700', color: colors.ink },
  ledgerLbl: { fontSize: 10, color: colors.muted, marginTop: 2 },
  empty: { textAlign: 'center', color: colors.muted, padding: 40 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.line, backgroundColor: colors.card },
  client: { fontSize: 14, fontWeight: '600', color: colors.ink },
  due: { fontSize: 12, color: colors.muted, marginTop: 2 },
  amount: { fontSize: 14, fontWeight: '700', color: colors.ink },
  badge: { borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2, marginTop: 4 },
  badgeText: { fontSize: 10, fontWeight: '600' },
  actions: { flexDirection: 'column', gap: 4 },
  action: { fontSize: 11, color: '#2563EB' },
  fab: { position: 'absolute', bottom: 24, alignSelf: 'center', backgroundColor: colors.ink, borderRadius: 24, paddingVertical: 13, paddingHorizontal: 22 },
  fabText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  promiseBackdrop: { flex: 1, backgroundColor: 'rgba(15,30,54,0.5)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  promiseSheet: { backgroundColor: colors.card, borderRadius: 14, padding: 18, width: '100%' },
  input: { borderWidth: 1, borderColor: colors.line, borderRadius: 10, padding: 12, fontSize: 15, color: colors.ink, marginTop: 10 },
  promiseActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 18, marginTop: 14 },
});
