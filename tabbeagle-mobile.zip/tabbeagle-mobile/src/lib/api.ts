import { supabase } from './supabase';
import { Invoice, InvoiceStatus, Tone } from '../types';

const API_URL = process.env.EXPO_PUBLIC_API_URL!;

// Mirrors the canonical backend's actual request/response shapes exactly
// (src/app/api/** in the tabbeagle Next.js app) — camelCase bodies in,
// the raw row back out, no {invoice: ...} wrapper.
async function authHeaders() {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function handle(res: Response) {
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || 'Request failed');
  return json;
}

export async function fetchInvoices(): Promise<Invoice[]> {
  const res = await fetch(`${API_URL}/api/invoices`, { headers: await authHeaders() });
  return handle(res);
}

export async function createInvoice(input: {
  orgId: string;
  clientName: string;
  clientEmail?: string;
  amount: number; // dollars — the server multiplies by 100 before storing
  dueDate: string;
}): Promise<Invoice> {
  const res = await fetch(`${API_URL}/api/invoices`, {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify(input),
  });
  return handle(res);
}

export async function updateInvoiceStatus(
  id: string,
  status: InvoiceStatus,
  extra?: { promised_date?: string; paid_date?: string }
): Promise<Invoice> {
  const res = await fetch(`${API_URL}/api/invoices/${id}`, {
    method: 'PATCH',
    headers: await authHeaders(),
    body: JSON.stringify({ status, ...extra }),
  });
  return handle(res);
}

// No payLink parameter: the server always mints a fresh Stripe link for
// each send now (see the backend's remind/route.ts fix) — the client
// never supplies one.
export async function sendReminder(id: string, tone: Tone): Promise<Invoice> {
  const res = await fetch(`${API_URL}/api/invoices/${id}/remind`, {
    method: 'POST',
    headers: await authHeaders(),
    body: JSON.stringify({ tone }),
  });
  return handle(res);
}

export async function createPaymentLink(id: string): Promise<string> {
  const res = await fetch(`${API_URL}/api/invoices/${id}/pay-link`, {
    method: 'POST',
    headers: await authHeaders(),
  });
  const json = await handle(res);
  return json.url;
}
