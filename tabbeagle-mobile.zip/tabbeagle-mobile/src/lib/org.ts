import { supabase } from './supabase';

// v1 is one organization per owner (see the backend's schema.sql comment),
// created manually via SQL today — there's no in-app signup flow yet. This
// reads it directly via Supabase (RLS already restricts it to rows the
// logged-in user owns), rather than through the Next.js API, since it's a
// simple read with no business logic attached.
export async function getMyOrganizationId(): Promise<string> {
  const { data, error } = await supabase.from('organizations').select('id').single();
  if (error || !data) {
    throw new Error(
      'No organization found for this account yet. Ask whoever set up Tabbeagle to create one for you.'
    );
  }
  return data.id;
}
