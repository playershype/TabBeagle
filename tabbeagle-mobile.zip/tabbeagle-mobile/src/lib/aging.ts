// Identical logic to the backend's src/lib/aging.ts — same bucket
// boundaries, same cents-to-display formatting, so a number never
// disagrees with itself between web and mobile.
import type { Invoice, InvoiceStatus, AgingBucket } from '../types';

export function daysOverdue(dueDateISO: string, today: Date = new Date()): number {
  const due = new Date(dueDateISO + 'T00:00:00');
  const t = new Date(today.toDateString());
  return Math.round((t.getTime() - due.getTime()) / 86400000);
}

export function bucketOf(invoice: Invoice): AgingBucket | 'paid' {
  if (invoice.status === 'paid') return 'paid';
  const days = daysOverdue(invoice.due_date);
  if (days <= 0) return 'current';
  if (days <= 30) return '1-30';
  if (days <= 60) return '31-60';
  if (days <= 90) return '61-90';
  return '90+';
}

export function fmtMoney(cents: number, currency = 'usd'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.toUpperCase(),
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

export function outstandingTotal(invoices: Invoice[]): number {
  return invoices.filter((i) => i.status !== 'paid').reduce((s, i) => s + i.amount_cents, 0);
}

export function recoveredThisMonth(invoices: Invoice[]): number {
  const now = new Date();
  return invoices
    .filter((i) => i.status === 'paid' && i.paid_date)
    .filter((i) => {
      const paid = new Date(i.paid_date as string);
      return paid.getMonth() === now.getMonth() && paid.getFullYear() === now.getFullYear();
    })
    .reduce((s, i) => s + i.amount_cents, 0);
}
