// Mirrors the canonical backend exactly: src/types/invoice.ts in the
// tabbeagle Next.js app. amount is in CENTS (integer) — never dollars —
// to match the database column. Converting for display happens only in
// src/lib/aging.ts's fmtMoney, same as the web app.
export type InvoiceStatus = 'open' | 'paid' | 'promised' | 'paused';
export type Tone = 'neutral' | 'friendly' | 'firm';

export interface Contact {
  id: string;
  org_id: string;
  name: string;
  email: string | null;
  phone: string | null;
}

export interface Invoice {
  id: string;
  org_id: string;
  contact_id: string;
  amount_cents: number;
  currency: string;
  due_date: string;
  status: InvoiceStatus;
  promised_date: string | null;
  paid_date: string | null;
  stripe_payment_link: string | null;
  created_at: string;
  contact?: Contact;
}

export type AgingBucket = 'current' | '1-30' | '31-60' | '61-90' | '90+';
