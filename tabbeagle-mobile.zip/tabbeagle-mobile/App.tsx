import React, { useEffect, useRef, useState } from 'react';
import { View, ActivityIndicator, Linking as RNLinking } from 'react-native';
import * as Linking from 'expo-linking';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './src/lib/supabase';
import { colors } from './src/theme';
import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import AddInvoiceScreen from './src/screens/AddInvoiceScreen';

const Stack = createNativeStackNavigator();

// Completes the magic-link sign-in: the email link opens this app via the
// "tabbeagle://" scheme (declared in app.json) carrying a PKCE "code" param.
// This exchanges that code for a real session. Handles both a cold start
// (app wasn't running yet) and a warm one (app was already open).
function useMagicLinkHandler() {
  useEffect(() => {
    async function consume(url: string | null) {
      if (!url) return;
      const { queryParams } = Linking.parse(url);
      const code = queryParams?.code;
      if (typeof code === 'string') {
        await supabase.auth.exchangeCodeForSession(code);
      }
    }
    Linking.getInitialURL().then(consume);
    const sub = RNLinking.addEventListener('url', ({ url }) => consume(url));
    return () => sub.remove();
  }, []);
}

export default function App() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  useMagicLinkHandler();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  // undefined = still checking for an existing session on launch
  if (session === undefined) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.paper }}>
        <ActivityIndicator color={colors.ink} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!session ? (
          <Stack.Screen name="Login" component={LoginScreen} />
        ) : (
          <>
            <Stack.Screen name="Dashboard" component={DashboardScreen} />
            <Stack.Screen
              name="AddInvoice"
              component={AddInvoiceScreen}
              options={{ presentation: 'modal', headerShown: true, title: 'New invoice' }}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
