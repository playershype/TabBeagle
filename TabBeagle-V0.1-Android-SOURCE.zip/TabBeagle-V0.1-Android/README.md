# TabBeagle V0.1 Android Preview

Canonical mobile preview assembled from the supplied Stitch export.

## Included routes
- Dashboard
- Invoices
- Invoice detail
- New invoice
- Reminders
- Settings / integrations
- Electronic invoice / payment link
- Payment confirmation / receipt

## Status
UI preview with demo data. Payment processors, ATH Movil validation, QuickBooks, email delivery, tax/fiscal treatment, and reconciliation are not claimed as live integrations in V0.1.

## Android
Capacitor 8 wrapper. GitHub Actions generates a debug APK artifact.
